package dominio;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "tab_pedido")
public class Pedido {
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long codigo;

	@Column(name = "data_pedido", nullable = false)
	private LocalDate dataPedido;
	
	@Column(name = "quantidade_itens",precision = 3, nullable = false)
	private Integer qtdItens;

	@Column(precision = 10, scale = 2, nullable = true)
	private BigDecimal valorTotal;
	
	@Column(name = "forma_pagameto", nullable = false)
	@Enumerated(EnumType.STRING) 
	private FormaPagamento formaPagamento;

	
	public Pedido() {
	}


	public Pedido(Long codigo, LocalDate dataPedido, Integer qtdItens, BigDecimal valorTotal,
			FormaPagamento formaPagamento) {
		super();
		this.codigo = codigo;
		this.dataPedido = dataPedido;
		this.qtdItens = qtdItens;
		this.valorTotal = valorTotal;
		this.formaPagamento = formaPagamento;
	}


	public Long getCodigo() {
		return codigo;
	}


	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}


	public LocalDate getDataPedido() {
		return dataPedido;
	}


	public void setDataPedido(LocalDate dataPedido) {
		this.dataPedido = dataPedido;
	}


	public Integer getQtdItens() {
		return qtdItens;
	}


	public void setQtdItens(Integer qtdItens) {
		this.qtdItens = qtdItens;
	}


	public BigDecimal getValorTotal() {
		return valorTotal;
	}


	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}


	public FormaPagamento getFormaPagamento() {
		return formaPagamento;
	}


	public void setFormaPagamento(FormaPagamento formaPagamento) {
		this.formaPagamento = formaPagamento;
	}


	@Override
	public int hashCode() {
		return Objects.hash(codigo, dataPedido, formaPagamento, qtdItens, valorTotal);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pedido other = (Pedido) obj;
		return Objects.equals(codigo, other.codigo) && Objects.equals(dataPedido, other.dataPedido)
				&& formaPagamento == other.formaPagamento && Objects.equals(qtdItens, other.qtdItens)
				&& Objects.equals(valorTotal, other.valorTotal);
	}

	
	
}
