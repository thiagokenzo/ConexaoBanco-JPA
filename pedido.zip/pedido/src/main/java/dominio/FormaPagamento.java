package dominio;

public enum FormaPagamento {

	CR�DITO, 
	D�BITO,
	DINHEIRO
	
}
