 package aplicacao;

import java.math.BigDecimal;
import java.time.LocalDate;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import dominio.FormaPagamento;
import dominio.Pedido;


public class Programa {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pedido");
		EntityManager em = emf.createEntityManager();

	
		em.getTransaction().begin(); 	
		
	
		Pedido pedido = new Pedido();
		pedido.setDataPedido(LocalDate.now());
		pedido.setQtdItens(3);
		pedido.setValorTotal(new BigDecimal(75.50));
		pedido.setFormaPagamento(FormaPagamento.CR�DITO);
		
		em.persist(pedido);
		
		
		Pedido pedido2 = new Pedido();
		pedido2.setDataPedido(LocalDate.now());
		pedido2.setQtdItens(5);
		pedido2.setValorTotal(new BigDecimal(225.90));
		pedido2.setFormaPagamento(FormaPagamento.D�BITO);
		
		em.persist(pedido2);
	
		

		System.out.println("pronto!");
		em.close(); 
		emf.close();

	}

}
