package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import dominio.Pedido;


public class BuscandoPedido {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pedido");
		EntityManager em = emf.createEntityManager();


		Pedido pedido = em.find(Pedido.class, 2L);
		System.out.println("Pedido de c�digo " + pedido.getCodigo()
		+ " tem valor total de R$" + pedido.getValorTotal());


		System.out.println("pronto!");
		em.close(); 
		emf.close();
		

	}

}
