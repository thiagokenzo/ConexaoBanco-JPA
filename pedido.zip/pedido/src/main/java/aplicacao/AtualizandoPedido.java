
package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;

import dominio.Pedido;

public class AtualizandoPedido {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pedido");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin(); 

		Pedido pedido = em.find(Pedido.class, 1L);
		
		System.out.println("Valor atual: " + pedido.getValorTotal());
		pedido.setValorTotal(pedido.getValorTotal().add(new BigDecimal(30)));
		System.out.println("Novo valor: " + pedido.getValorTotal());

		em.getTransaction().commit();

		System.out.println("pronto!");
		em.close(); 
		emf.close();

	}

}
