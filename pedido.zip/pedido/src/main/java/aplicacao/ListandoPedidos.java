package aplicacao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

import dominio.Pedido;


public class ListandoPedidos {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("pedido");
		EntityManager em = emf.createEntityManager();


		Query query = em.createQuery("select v from Pedido v");
		
		List<Pedido> pedidos = query.getResultList();
		for (Pedido pedido : pedidos) {
			System.out.println("Pedido de c�digo " + pedido.getCodigo() + " --->  Data do pedido: " 
					+ pedido.getDataPedido() + " --- Quantidade de itens: " 
					+ pedido.getQtdItens() + " --- Valor Total: R$" 
					+ pedido.getValorTotal() + " --- Forma de Pagamento: " 
					+ pedido.getFormaPagamento());
		}


		System.out.println("pronto!");
		em.close();
		emf.close();

	}

}
